	<div class="col-md-4" style="margin-bottom:10px; "  >
    	<div>
        	<h4 style="padding-top:0px; margin-top:0px;">Informasi & Pengumuman</h4>
            <div id="infopengumuman" style="margin-top:15px;"></div>
        </div>
        <br/>
        
        <div>
        	<h4 style="padding-top:0px; margin-top:0px;">Pengunjung</h4>
            <div id="viewviewer" style="margin-top:15px;"></div>
        </div>
        <br/>
        
        <div>
              <h4>Tentang Website</h4>
             This site is best viewed with Google Chrome.<br/><br/>
<img src="https://ferrebeekeeper.files.wordpress.com/2012/08/600px-celtic-knot-insquare-39crossings-svg.png?w=490&h=490" class="img-responsive" width="80%"/>
        </div>
   
        

    </div>

</div>
</div>
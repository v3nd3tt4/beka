<h2>kotak saran</h2>

<p>Tinggal kan pesan untuk kami, dan kami akan segera merespon pesan yang anda kirimkan pada kami. gunakanlah bahasa yang baik & sopan dalam memberikan pesan</p>

<div id="notifsaran"></div>
<form id="submitSaran">
  <div class="form-group">
    <label for="email">Nama:</label>
    <input type="text" class="form-control" id="namaSaran" name="namaSaran">
  </div>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="emailSaran" name="emailSaran">
  </div>
  <div class="form-group">
    <label for="email">Pesan:</label>
    <textarea class="form-control" id="pesanSaran" name="pesanSaran" rows="10" style="resize:none"></textarea>
  </div>
  <div class="form-group">
    <button type="submit" class="btn btn-primary">Submit..</button>
  </div>
</form>
</div>
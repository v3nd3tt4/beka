<?php
include 'header.php';
include 'sidebar.php';
include 'navbar.php';
include 'content.php';
include 'footer.php';
include 'js.php';
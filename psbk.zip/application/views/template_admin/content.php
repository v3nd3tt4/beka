<?php
$this->load->view($page);

?>